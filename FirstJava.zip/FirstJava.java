public class FirstJava {
	public static void main(String[] args) {

    System.out.println("My name is Cesar");
    System.out.println("I am 29 y/o");
    System.out.println("My hometown is Fresno, CA");

	}
}
